import { useState, useReducer, useMemo, useEffect } from "react";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend
} from "recharts";

// ─── Mock Data ─────────────────────────────────────────────────────────────
const INITIAL_TRANSACTIONS = [
  { id: 1,  date: "2024-11-05", desc: "Monthly Salary",     amount: 5800, type: "income",  cat: "Salary" },
  { id: 2,  date: "2024-11-03", desc: "Freelance Project",  amount: 1200, type: "income",  cat: "Freelance" },
  { id: 3,  date: "2024-11-08", desc: "Apartment Rent",     amount: 1500, type: "expense", cat: "Housing" },
  { id: 4,  date: "2024-11-10", desc: "Grocery Store",      amount: 185,  type: "expense", cat: "Food" },
  { id: 5,  date: "2024-11-11", desc: "Uber Rides",         amount: 42,   type: "expense", cat: "Transport" },
  { id: 6,  date: "2024-11-14", desc: "Netflix & Spotify",  amount: 28,   type: "expense", cat: "Entertainment" },
  { id: 7,  date: "2024-11-16", desc: "Pharmacy",           amount: 75,   type: "expense", cat: "Health" },
  { id: 8,  date: "2024-11-18", desc: "Amazon Shopping",    amount: 234,  type: "expense", cat: "Shopping" },
  { id: 9,  date: "2024-11-20", desc: "Restaurant Dinner",  amount: 96,   type: "expense", cat: "Food" },
  { id: 10, date: "2024-11-22", desc: "Bus Pass",           amount: 35,   type: "expense", cat: "Transport" },
  { id: 11, date: "2024-10-05", desc: "Monthly Salary",     amount: 5800, type: "income",  cat: "Salary" },
  { id: 12, date: "2024-10-07", desc: "Freelance Design",   amount: 850,  type: "income",  cat: "Freelance" },
  { id: 13, date: "2024-10-10", desc: "Apartment Rent",     amount: 1500, type: "expense", cat: "Housing" },
  { id: 14, date: "2024-10-12", desc: "Grocery Store",      amount: 210,  type: "expense", cat: "Food" },
  { id: 15, date: "2024-10-15", desc: "Metro Card",         amount: 30,   type: "expense", cat: "Transport" },
  { id: 16, date: "2024-10-18", desc: "Movie Tickets",      amount: 54,   type: "expense", cat: "Entertainment" },
  { id: 17, date: "2024-10-20", desc: "Doctor Visit",       amount: 150,  type: "expense", cat: "Health" },
  { id: 18, date: "2024-10-24", desc: "Clothing Store",     amount: 180,  type: "expense", cat: "Shopping" },
  { id: 19, date: "2024-09-05", desc: "Monthly Salary",     amount: 5800, type: "income",  cat: "Salary" },
  { id: 20, date: "2024-09-12", desc: "Apartment Rent",     amount: 1500, type: "expense", cat: "Housing" },
  { id: 21, date: "2024-09-14", desc: "Grocery Run",        amount: 165,  type: "expense", cat: "Food" },
  { id: 22, date: "2024-09-16", desc: "Gas Station",        amount: 60,   type: "expense", cat: "Transport" },
  { id: 23, date: "2024-09-19", desc: "Gym Membership",     amount: 45,   type: "expense", cat: "Health" },
  { id: 24, date: "2024-09-22", desc: "Online Course",      amount: 99,   type: "expense", cat: "Entertainment" },
  { id: 25, date: "2024-09-25", desc: "Freelance Work",     amount: 2100, type: "income",  cat: "Freelance" },
];

const CATEGORIES = ["Salary","Freelance","Housing","Food","Transport","Entertainment","Health","Shopping"];
const CAT_ICONS = { Salary:"💼", Freelance:"💻", Housing:"🏠", Food:"🍽", Transport:"🚗", Entertainment:"🎬", Health:"💊", Shopping:"🛍" };
const CAT_COLORS = { Salary:"#3ecf8e", Freelance:"#c9a84c", Housing:"#a78bfa", Food:"#f0a070", Transport:"#60a5fa", Entertainment:"#f87171", Health:"#67e8f9", Shopping:"#e879f9" };
const CHART_COLORS = ["#c9a84c","#60a5fa","#a78bfa","#3ecf8e","#f87171","#f0a070","#67e8f9","#e879f9"];
const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

// ─── State Management ───────────────────────────────────────────────────────
const initState = () => {
  try {
    const saved = localStorage.getItem("finvault");
    if (saved) return JSON.parse(saved);
  } catch {}
  return { transactions: INITIAL_TRANSACTIONS, nextId: 30 };
};

function reducer(state, action) {
  switch (action.type) {
    case "ADD_TXN":    return { ...state, transactions: [...state.transactions, { ...action.payload, id: state.nextId }], nextId: state.nextId + 1 };
    case "EDIT_TXN":   return { ...state, transactions: state.transactions.map(t => t.id === action.payload.id ? action.payload : t) };
    case "DELETE_TXN": return { ...state, transactions: state.transactions.filter(t => t.id !== action.payload) };
    default:           return state;
  }
}

// ─── Utils ──────────────────────────────────────────────────────────────────
const fmt = n => "$" + Math.abs(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtShort = n => n >= 1000 ? "$" + (n / 1000).toFixed(1) + "k" : "$" + n;

// ─── Styles (CSS-in-JS object) ──────────────────────────────────────────────
const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500;9..40,600&display=swap');
  *{box-sizing:border-box;margin:0;padding:0}
  :root{
    --bg:#0d1117;--surface:#161b22;--surface2:#1c2332;--surface3:#222d40;
    --border:#2a3650;--border2:#334060;
    --text:#e8edf5;--text2:#8899b0;--text3:#5a6a80;
    --gold:#c9a84c;--gold2:#e8c96a;--gold3:#f5dfa0;
    --green:#3ecf8e;--red:#f87171;--blue:#60a5fa;--purple:#a78bfa;
  }
  body{font-family:'DM Sans',sans-serif;background:var(--bg);color:var(--text);min-height:100vh;font-size:14px}
  ::-webkit-scrollbar{width:4px;height:4px}
  ::-webkit-scrollbar-track{background:transparent}
  ::-webkit-scrollbar-thumb{background:var(--border2);border-radius:2px}
  input,select,textarea{font-family:'DM Sans',sans-serif}
  input[type=date]::-webkit-calendar-picker-indicator{filter:invert(1) opacity(0.3)}
`;

// ─── Sub-Components ──────────────────────────────────────────────────────────

function SummaryCard({ label, value, change, changeLabel, icon, color }) {
  const iconBg = { gold: "#c9a84c22", green: "#3ecf8e18", red: "#f8717118", blue: "#60a5fa18" };
  const iconClr = { gold: "#e8c96a", green: "#3ecf8e", red: "#f87171", blue: "#60a5fa" };
  const valClr = { gold: "#e8c96a", green: "#3ecf8e", red: "#f87171", blue: "#60a5fa", default: "#e8edf5" };
  return (
    <div style={{ background: "var(--surface)", border: "1px solid var(--border)", borderRadius: 12, padding: 18 }}>
      <div style={{ width: 32, height: 32, borderRadius: 8, background: iconBg[color], display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 12, fontSize: 14, color: iconClr[color] }}>{icon}</div>
      <div style={{ fontSize: 11, color: "var(--text3)", textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 }}>{label}</div>
      <div style={{ fontSize: 24, fontFamily: "'DM Serif Display',serif", color: valClr[color] || valClr.default }}>{value}</div>
      {changeLabel && <div style={{ fontSize: 11, marginTop: 4, color: change > 0 ? "var(--green)" : change < 0 ? "var(--red)" : "var(--text3)" }}>{changeLabel}</div>}
    </div>
  );
}

function CatBadge({ cat }) {
  const bg = CAT_COLORS[cat] + "20";
  const color = CAT_COLORS[cat] || "#888";
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 4, padding: "3px 8px", borderRadius: 4, background: bg, color, fontSize: 11, fontWeight: 600 }}>
      {CAT_ICONS[cat]} {cat}
    </span>
  );
}

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background: "#1c2332", border: "1px solid #2a3650", borderRadius: 8, padding: "10px 14px" }}>
      <div style={{ fontSize: 12, color: "#8899b0", marginBottom: 6 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ fontSize: 13, color: p.color, marginBottom: 2 }}>{p.name}: {fmt(p.value)}</div>
      ))}
    </div>
  );
}

function TransactionModal({ txn, onSave, onClose }) {
  const [form, setForm] = useState(txn || { desc: "", amount: "", type: "expense", cat: "Food", date: new Date().toISOString().split("T")[0] });
  const [err, setErr] = useState("");
  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));
  const save = () => {
    if (!form.desc.trim() || !form.date) { setErr("Please fill all fields."); return; }
    const amt = parseFloat(form.amount);
    if (isNaN(amt) || amt <= 0) { setErr("Enter a valid amount."); return; }
    onSave({ ...form, amount: amt });
  };
  const inp = { background: "var(--surface2)", border: "1px solid var(--border)", color: "var(--text)", padding: "8px 12px", borderRadius: 6, fontSize: 13, width: "100%", outline: "none" };
  const lbl = { fontSize: 11, color: "var(--text3)", textTransform: "uppercase", letterSpacing: 0.8, marginBottom: 5, display: "block" };
  return (
    <div onClick={e => e.target === e.currentTarget && onClose()} style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,.75)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 100 }}>
      <div style={{ background: "var(--surface)", border: "1px solid var(--border2)", borderRadius: 14, padding: 24, width: 360, maxWidth: "90vw" }}>
        <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 20 }}>{txn ? "Edit Transaction" : "New Transaction"}</div>
        {[["Description","text","desc",form.desc,v=>set("desc",v)],["Amount ($)","number","amount",form.amount,v=>set("amount",v)],["Date","date","date",form.date,v=>set("date",v)]].map(([label,type,key,val,fn])=>(
          <div key={key} style={{ marginBottom: 14 }}>
            <label style={lbl}>{label}</label>
            <input style={inp} type={type} value={val} onChange={e=>fn(e.target.value)} min={type==="number"?"0":undefined} step={type==="number"?"0.01":undefined} placeholder={type==="text"?"e.g. Grocery Store":type==="number"?"0.00":undefined}/>
          </div>
        ))}
        <div style={{ marginBottom: 14 }}>
          <label style={lbl}>Type</label>
          <select style={inp} value={form.type} onChange={e=>set("type",e.target.value)}>
            <option value="expense">Expense</option>
            <option value="income">Income</option>
          </select>
        </div>
        <div style={{ marginBottom: 14 }}>
          <label style={lbl}>Category</label>
          <select style={inp} value={form.cat} onChange={e=>set("cat",e.target.value)}>
            {CATEGORIES.map(c=><option key={c} value={c}>{CAT_ICONS[c]} {c}</option>)}
          </select>
        </div>
        {err && <div style={{ fontSize: 12, color: "var(--red)", marginBottom: 12 }}>{err}</div>}
        <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
          <button onClick={onClose} style={{ padding:"7px 14px", background:"transparent", color:"var(--text2)", border:"1px solid var(--border)", borderRadius:6, fontSize:12, cursor:"pointer" }}>Cancel</button>
          <button onClick={save} style={{ padding:"7px 14px", background:"var(--gold)", color:"#1a1200", border:"none", borderRadius:6, fontSize:12, fontWeight:600, cursor:"pointer" }}>{txn ? "Update" : "Add"}</button>
        </div>
      </div>
    </div>
  );
}

// ─── Pages ───────────────────────────────────────────────────────────────────

function Overview({ transactions }) {
  const income = transactions.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0);
  const expense = transactions.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);
  const balance = income - expense;
  const savings = income > 0 ? ((balance/income)*100).toFixed(1) : 0;

  const monthly = useMemo(() => {
    const m = {};
    transactions.forEach(t => {
      const d = new Date(t.date);
      const k = `${d.getFullYear()}-${d.getMonth()}`;
      const lbl = MONTHS[d.getMonth()] + " '" + String(d.getFullYear()).slice(2);
      if (!m[k]) m[k] = { lbl, income: 0, expense: 0, sort: d.getFullYear()*100+d.getMonth() };
      if (t.type==="income") m[k].income += t.amount;
      else m[k].expense += t.amount;
    });
    return Object.values(m).sort((a,b)=>a.sort-b.sort);
  }, [transactions]);

  const catSpend = useMemo(() => {
    const c = {};
    transactions.filter(t=>t.type==="expense").forEach(t=>{ c[t.cat]=(c[t.cat]||0)+t.amount; });
    return Object.entries(c).sort((a,b)=>b[1]-a[1]);
  }, [transactions]);

  const recent = [...transactions].sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,5);

  return (
    <div>
      {/* Summary Cards */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))", gap:16, marginBottom:24 }}>
        <SummaryCard label="Total Balance" value={fmt(balance)} changeLabel={`Savings rate ${savings}%`} icon="⬡" color="gold"/>
        <SummaryCard label="Total Income" value={fmt(income)} changeLabel={`${transactions.filter(t=>t.type==="income").length} income entries`} icon="↑" color="green"/>
        <SummaryCard label="Total Expenses" value={fmt(expense)} changeLabel={`${transactions.filter(t=>t.type==="expense").length} expense entries`} icon="↓" color="red"/>
        <SummaryCard label="Transactions" value={transactions.length} changeLabel="All time records" icon="◈" color="blue"/>
      </div>

      {/* Charts */}
      <div style={{ display:"grid", gridTemplateColumns:"2fr 1fr", gap:16, marginBottom:24 }}>
        <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:12, padding:20 }}>
          <div style={{ fontSize:14, fontWeight:600, marginBottom:4 }}>Monthly Cash Flow</div>
          <div style={{ fontSize:11, color:"var(--text3)", marginBottom:16 }}>Income vs expenses by month</div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={monthly}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a3650"/>
              <XAxis dataKey="lbl" tick={{fill:"#8899b0",fontSize:11}} axisLine={{stroke:"#2a3650"}} tickLine={false}/>
              <YAxis tick={{fill:"#8899b0",fontSize:11}} axisLine={false} tickLine={false} tickFormatter={v=>"$"+v.toLocaleString()}/>
              <Tooltip content={<CustomTooltip/>}/>
              <Line type="monotone" dataKey="income" name="Income" stroke="#3ecf8e" strokeWidth={2} dot={{fill:"#3ecf8e",r:4}} activeDot={{r:6}}/>
              <Line type="monotone" dataKey="expense" name="Expenses" stroke="#f87171" strokeWidth={2} dot={{fill:"#f87171",r:4}} activeDot={{r:6}}/>
            </LineChart>
          </ResponsiveContainer>
          <div style={{ display:"flex", gap:16, marginTop:8, justifyContent:"center" }}>
            {[["Income","#3ecf8e"],["Expenses","#f87171"]].map(([l,c])=>(
              <span key={l} style={{ display:"flex", alignItems:"center", gap:5, fontSize:11, color:"var(--text2)" }}>
                <span style={{ width:10, height:10, borderRadius:2, background:c, display:"inline-block" }}/>{l}
              </span>
            ))}
          </div>
        </div>
        <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:12, padding:20 }}>
          <div style={{ fontSize:14, fontWeight:600, marginBottom:4 }}>Spending by Category</div>
          <div style={{ fontSize:11, color:"var(--text3)", marginBottom:16 }}>Expense breakdown</div>
          {catSpend.length === 0 ? <div style={{color:"var(--text3)",fontSize:13,textAlign:"center",padding:40}}>No expense data</div> :
            catSpend.map((c,i) => (
              <div key={c[0]} style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
                <span style={{ fontSize:11, color:"var(--text2)", width:88, flexShrink:0 }}>{c[0]}</span>
                <div style={{ flex:1, height:6, background:"var(--surface3)", borderRadius:3, overflow:"hidden" }}>
                  <div style={{ height:"100%", width:`${((c[1]/catSpend[0][1])*100).toFixed(0)}%`, background:CHART_COLORS[i%CHART_COLORS.length], borderRadius:3, transition:"width .6s" }}/>
                </div>
                <span style={{ fontSize:11, color:"var(--text3)", width:40, textAlign:"right", flexShrink:0 }}>{fmtShort(c[1])}</span>
              </div>
            ))
          }
        </div>
      </div>

      {/* Recent Transactions */}
      <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:12, padding:20 }}>
        <div style={{ fontSize:14, fontWeight:600, marginBottom:4 }}>Recent Transactions</div>
        <div style={{ fontSize:11, color:"var(--text3)", marginBottom:16 }}>Last 5 entries</div>
        {recent.length === 0 ? <div style={{color:"var(--text3)",textAlign:"center",padding:32,fontSize:13}}>No transactions yet</div> :
          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse" }}>
              <thead>
                <tr>{["Date","Description","Category","Amount"].map(h=>(
                  <th key={h} style={{ textAlign:h==="Amount"?"right":"left", fontSize:10, color:"var(--text3)", textTransform:"uppercase", letterSpacing:1, padding:"8px 12px", borderBottom:"1px solid var(--border)", fontWeight:500 }}>{h}</th>
                ))}</tr>
              </thead>
              <tbody>
                {recent.map(t=>(
                  <tr key={t.id} style={{ borderBottom:"1px solid #2a365050" }}>
                    <td style={{ padding:"11px 12px", fontSize:13, color:"var(--text3)" }}>{t.date}</td>
                    <td style={{ padding:"11px 12px", fontSize:13 }}>{t.desc}</td>
                    <td style={{ padding:"11px 12px" }}><CatBadge cat={t.cat}/></td>
                    <td style={{ padding:"11px 12px", fontSize:13, textAlign:"right", color:t.type==="income"?"var(--green)":"var(--red)", fontWeight:t.type==="income"?600:400 }}>
                      {t.type==="income"?"+":"-"}{fmt(t.amount)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        }
      </div>
    </div>
  );
}

function Transactions({ transactions, role, dispatch }) {
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [catFilter, setCatFilter] = useState("all");
  const [sort, setSort] = useState({ field: "date", dir: "desc" });
  const [modal, setModal] = useState(null); // null | "new" | txn-object
  const [toast, setToast] = useState("");

  const showToast = msg => { setToast(msg); setTimeout(()=>setToast(""),2500); };

  const filtered = useMemo(() => {
    let txns = [...transactions];
    if (search) { const q=search.toLowerCase(); txns=txns.filter(t=>t.desc.toLowerCase().includes(q)||t.cat.toLowerCase().includes(q)); }
    if (typeFilter!=="all") txns=txns.filter(t=>t.type===typeFilter);
    if (catFilter!=="all") txns=txns.filter(t=>t.cat===catFilter);
    txns.sort((a,b)=>{
      let av=a[sort.field], bv=b[sort.field];
      if(sort.field==="amount"){av=Number(av);bv=Number(bv);}
      if(av<bv) return sort.dir==="asc"?-1:1;
      if(av>bv) return sort.dir==="asc"?1:-1;
      return 0;
    });
    return txns;
  }, [transactions, search, typeFilter, catFilter, sort]);

  const sortBy = field => setSort(s => s.field===field ? {...s,dir:s.dir==="asc"?"desc":"asc"} : {field,dir:"desc"});
  const SortIcon = ({field}) => sort.field===field ? (sort.dir==="asc"?"↑":"↓") : <span style={{opacity:.3}}>↕</span>;

  const allCats = [...new Set(transactions.map(t=>t.cat))];
  const isAdmin = role==="admin";
  const sel = { background:"var(--surface2)", border:"1px solid var(--border)", color:"var(--text)", padding:"6px 10px", borderRadius:6, fontSize:12, cursor:"pointer", outline:"none" };

  return (
    <div>
      {/* Header */}
      <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:16, gap:12, flexWrap:"wrap" }}>
        <div style={{ fontSize:14, fontWeight:600 }}>All Transactions</div>
        <div style={{ display:"flex", gap:8, alignItems:"center", flexWrap:"wrap" }}>
          <div style={{ position:"relative" }}>
            <span style={{ position:"absolute", left:9, top:"50%", transform:"translateY(-50%)", color:"var(--text3)", fontSize:12, pointerEvents:"none" }}>⌕</span>
            <input type="text" placeholder="Search..." value={search} onChange={e=>setSearch(e.target.value)}
              style={{ ...sel, paddingLeft:28, width:180 }}/>
          </div>
          <select style={sel} value={typeFilter} onChange={e=>setTypeFilter(e.target.value)}>
            <option value="all">All Types</option>
            <option value="income">Income</option>
            <option value="expense">Expense</option>
          </select>
          <select style={sel} value={catFilter} onChange={e=>setCatFilter(e.target.value)}>
            <option value="all">All Categories</option>
            {allCats.map(c=><option key={c} value={c}>{c}</option>)}
          </select>
          {isAdmin && (
            <button onClick={()=>setModal("new")} style={{ padding:"7px 14px", background:"var(--gold)", color:"#1a1200", border:"none", borderRadius:6, fontSize:12, fontWeight:600, cursor:"pointer" }}>+ Add</button>
          )}
        </div>
      </div>

      {/* Table */}
      <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:12, overflow:"hidden" }}>
        <div style={{ overflowX:"auto" }}>
          <table style={{ width:"100%", borderCollapse:"collapse" }}>
            <thead>
              <tr>
                {[["date","Date"],["desc","Description"],["cat","Category"],["type","Type"],["amount","Amount"]].map(([f,l])=>(
                  <th key={f} onClick={()=>sortBy(f)} style={{ textAlign:f==="amount"?"right":"left", fontSize:10, color:"var(--text3)", textTransform:"uppercase", letterSpacing:1, padding:"10px 12px", borderBottom:"1px solid var(--border)", fontWeight:500, cursor:"pointer", whiteSpace:"nowrap", userSelect:"none" }}>
                    {l} <SortIcon field={f}/>
                  </th>
                ))}
                {isAdmin && <th style={{ padding:"10px 12px", borderBottom:"1px solid var(--border)" }}/>}
              </tr>
            </thead>
            <tbody>
              {filtered.length===0 ? (
                <tr><td colSpan={isAdmin?6:5} style={{ textAlign:"center", padding:48, color:"var(--text3)", fontSize:13 }}>
                  {search||typeFilter!=="all"||catFilter!=="all" ? "No transactions match your filters." : "No transactions yet."}
                </td></tr>
              ) : filtered.map(t=>(
                <tr key={t.id} style={{ borderBottom:"1px solid #2a365048" }}>
                  <td style={{ padding:"11px 12px", fontSize:13, color:"var(--text3)", whiteSpace:"nowrap" }}>{t.date}</td>
                  <td style={{ padding:"11px 12px", fontSize:13, fontWeight:500 }}>{t.desc}</td>
                  <td style={{ padding:"11px 12px" }}><CatBadge cat={t.cat}/></td>
                  <td style={{ padding:"11px 12px", fontSize:12, color:t.type==="income"?"var(--green)":"var(--red)", fontWeight:600 }}>{t.type.charAt(0).toUpperCase()+t.type.slice(1)}</td>
                  <td style={{ padding:"11px 12px", fontSize:13, textAlign:"right", color:t.type==="income"?"var(--green)":"var(--red)", fontWeight:t.type==="income"?600:400, whiteSpace:"nowrap" }}>
                    {t.type==="income"?"+":"-"}{fmt(t.amount)}
                  </td>
                  {isAdmin && (
                    <td style={{ padding:"11px 12px", textAlign:"right", whiteSpace:"nowrap" }}>
                      <button onClick={()=>setModal(t)} style={{ padding:"4px 10px", background:"transparent", color:"var(--text3)", border:"1px solid var(--border)", borderRadius:6, fontSize:11, cursor:"pointer", marginRight:4 }}>Edit</button>
                      <button onClick={()=>{ dispatch({type:"DELETE_TXN",payload:t.id}); showToast("Deleted"); }} style={{ padding:"4px 10px", background:"transparent", color:"var(--red)", border:"1px solid #f8717130", borderRadius:6, fontSize:11, cursor:"pointer" }}>Del</button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <div style={{ fontSize:11, color:"var(--text3)", marginTop:8 }}>
        {filtered.length} of {transactions.length} transactions{role==="viewer"?" · View-only mode — switch to Admin to edit":""}
      </div>

      {modal && (
        <TransactionModal
          txn={modal==="new"?null:modal}
          onClose={()=>setModal(null)}
          onSave={data=>{
            if(modal==="new") dispatch({type:"ADD_TXN",payload:data});
            else dispatch({type:"EDIT_TXN",payload:{...modal,...data}});
            showToast(modal==="new"?"Transaction added":"Transaction updated");
            setModal(null);
          }}
        />
      )}
      {toast && <div style={{ position:"fixed", bottom:24, right:24, background:"var(--surface2)", border:"1px solid var(--border2)", color:"var(--text)", padding:"10px 16px", borderRadius:8, fontSize:13, zIndex:200 }}>{toast}</div>}
    </div>
  );
}

function Insights({ transactions }) {
  const income = transactions.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0);
  const expense = transactions.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);
  const balance = income - expense;
  const savings = income > 0 ? ((balance/income)*100).toFixed(1) : 0;

  const catSpend = useMemo(()=>{
    const c={};
    transactions.filter(t=>t.type==="expense").forEach(t=>{c[t.cat]=(c[t.cat]||0)+t.amount;});
    return Object.entries(c).sort((a,b)=>b[1]-a[1]);
  },[transactions]);

  const monthly = useMemo(()=>{
    const m={};
    transactions.forEach(t=>{
      const d=new Date(t.date);
      const k=`${d.getFullYear()}-${d.getMonth()}`;
      const lbl=MONTHS[d.getMonth()]+" '"+String(d.getFullYear()).slice(2);
      if(!m[k]) m[k]={lbl,income:0,expense:0,sort:d.getFullYear()*100+d.getMonth()};
      if(t.type==="income") m[k].income+=t.amount; else m[k].expense+=t.amount;
    });
    return Object.values(m).sort((a,b)=>a.sort-b.sort);
  },[transactions]);

  const lastTwo = monthly.slice(-2);
  const expChange = lastTwo.length===2 ? (((lastTwo[1].expense-lastTwo[0].expense)/lastTwo[0].expense)*100).toFixed(1) : null;
  const incChange = lastTwo.length===2 ? (((lastTwo[1].income-lastTwo[0].income)/lastTwo[0].income)*100).toFixed(1) : null;
  const topCat = catSpend[0];

  const pieData = catSpend.map((c,i)=>({name:c[0],value:c[1],color:CHART_COLORS[i%CHART_COLORS.length]}));

  return (
    <div>
      {/* Insight cards */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))", gap:16, marginBottom:24 }}>
        {[
          { label:"Top Spending Category", value:topCat?topCat[0]:"—", desc:topCat?`${fmt(topCat[1])} — ${((topCat[1]/expense)*100).toFixed(0)}% of expenses`:"No expense data" },
          { label:"Savings Rate", value:`${savings}%`, desc:savings>=20?"Excellent — meeting the 20% benchmark":savings>=10?"Good — room to grow toward 20%":"Below 10% — review discretionary spend" },
          { label:"Net Position", value:fmt(balance), desc:`${fmt(income)} income · ${fmt(expense)} expenses`, valueColor:balance>=0?"var(--green)":"var(--red)" },
          { label:"Monthly Expense Δ", value:expChange!==null?(expChange>0?`+${expChange}%`:`${expChange}%`):"—", desc:lastTwo.length===2?`${lastTwo[0].lbl} → ${lastTwo[1].lbl}`:"Need 2+ months of data", valueColor:expChange>0?"var(--red)":"var(--green)" },
        ].map(c=>(
          <div key={c.label} style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:12, padding:18 }}>
            <div style={{ fontSize:11, color:"var(--text3)", textTransform:"uppercase", letterSpacing:1, marginBottom:8 }}>{c.label}</div>
            <div style={{ fontSize:22, fontFamily:"'DM Serif Display',serif", color:c.valueColor||"var(--gold2)", marginBottom:4 }}>{c.value}</div>
            <div style={{ fontSize:11, color:"var(--text2)", lineHeight:1.5 }}>{c.desc}</div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, marginBottom:24 }}>
        <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:12, padding:20 }}>
          <div style={{ fontSize:14, fontWeight:600, marginBottom:4 }}>Monthly Income vs Expenses</div>
          <div style={{ fontSize:11, color:"var(--text3)", marginBottom:16 }}>
            {incChange!==null?`Income ${incChange>0?"up":"down"} ${Math.abs(incChange)}% month-over-month`:"Trend by month"}
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={monthly}>
              <CartesianGrid strokeDasharray="3 3" stroke="#2a3650"/>
              <XAxis dataKey="lbl" tick={{fill:"#8899b0",fontSize:11}} axisLine={{stroke:"#2a3650"}} tickLine={false}/>
              <YAxis tick={{fill:"#8899b0",fontSize:11}} axisLine={false} tickLine={false} tickFormatter={v=>"$"+v.toLocaleString()}/>
              <Tooltip content={<CustomTooltip/>}/>
              <Bar dataKey="income" name="Income" fill="#3ecf8e" radius={[4,4,0,0]}/>
              <Bar dataKey="expense" name="Expenses" fill="#f87171" radius={[4,4,0,0]}/>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:12, padding:20 }}>
          <div style={{ fontSize:14, fontWeight:600, marginBottom:4 }}>Category Distribution</div>
          <div style={{ fontSize:11, color:"var(--text3)", marginBottom:16 }}>Share of total expenses</div>
          {pieData.length===0 ? <div style={{color:"var(--text3)",textAlign:"center",padding:32,fontSize:13}}>No expense data</div> : <>
            <ResponsiveContainer width="100%" height={160}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={72} dataKey="value" paddingAngle={3}>
                  {pieData.map((entry,i)=><Cell key={i} fill={entry.color}/>)}
                </Pie>
                <Tooltip formatter={(v)=>[fmt(v),"Amount"]}/>
              </PieChart>
            </ResponsiveContainer>
            <div style={{ display:"flex", flexWrap:"wrap", gap:8, marginTop:8 }}>
              {pieData.map(p=>(
                <span key={p.name} style={{ display:"flex", alignItems:"center", gap:4, fontSize:11, color:"var(--text2)" }}>
                  <span style={{ width:8, height:8, borderRadius:2, background:p.color, display:"inline-block" }}/>{p.name} {((p.value/expense)*100).toFixed(0)}%
                </span>
              ))}
            </div>
          </>}
        </div>
      </div>

      {/* Expense trend */}
      <div style={{ background:"var(--surface)", border:"1px solid var(--border)", borderRadius:12, padding:20 }}>
        <div style={{ fontSize:14, fontWeight:600, marginBottom:4 }}>Expense Trend</div>
        <div style={{ fontSize:11, color:"var(--text3)", marginBottom:16 }}>Monthly spending over time</div>
        <ResponsiveContainer width="100%" height={180}>
          <LineChart data={monthly}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2a3650"/>
            <XAxis dataKey="lbl" tick={{fill:"#8899b0",fontSize:11}} axisLine={{stroke:"#2a3650"}} tickLine={false}/>
            <YAxis tick={{fill:"#8899b0",fontSize:11}} axisLine={false} tickLine={false} tickFormatter={v=>"$"+v.toLocaleString()}/>
            <Tooltip content={<CustomTooltip/>}/>
            <Line type="monotone" dataKey="expense" name="Expenses" stroke="#f87171" strokeWidth={2} dot={{fill:"#f87171",r:4}} activeDot={{r:6}}/>
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [dbState, dispatch] = useReducer(reducer, null, initState);
  const [tab, setTab] = useState("overview");
  const [role, setRole] = useState("admin");

  // Persist to localStorage
  useEffect(() => {
    try { localStorage.setItem("finvault", JSON.stringify(dbState)); } catch {}
  }, [dbState]);

  const NAVS = [
    { id:"overview",     label:"Overview",     icon:"▦" },
    { id:"transactions", label:"Transactions", icon:"⇄" },
    { id:"insights",     label:"Insights",     icon:"◈" },
  ];

  return (
    <>
      <style>{CSS}</style>
      <div style={{ display:"flex", height:"100vh", overflow:"hidden" }}>
        {/* Sidebar */}
        <aside style={{ width:220, background:"var(--surface)", borderRight:"1px solid var(--border)", display:"flex", flexDirection:"column", flexShrink:0 }}>
          <div style={{ padding:"20px 20px 16px", borderBottom:"1px solid var(--border)" }}>
            <div style={{ fontFamily:"'DM Serif Display',serif", fontSize:22, color:"var(--gold2)" }}>FinVault</div>
            <div style={{ fontSize:10, color:"var(--text3)", letterSpacing:2, textTransform:"uppercase", marginTop:2 }}>Finance OS</div>
          </div>
          <nav style={{ padding:"12px 0" }}>
            {NAVS.map(n=>(
              <div key={n.id} onClick={()=>setTab(n.id)}
                style={{ display:"flex", alignItems:"center", gap:10, padding:"10px 20px", color:tab===n.id?"var(--gold2)":"var(--text2)", cursor:"pointer", borderLeft:`2px solid ${tab===n.id?"var(--gold2)":"transparent"}`, background:tab===n.id?"rgba(201,168,76,.08)":"transparent", fontSize:13, fontWeight:500, transition:"all .15s" }}>
                <span style={{ fontSize:14 }}>{n.icon}</span>
                <span>{n.label}</span>
              </div>
            ))}
          </nav>
          <div style={{ marginTop:"auto", padding:"16px 20px", borderTop:"1px solid var(--border)" }}>
            <div style={{ display:"inline-flex", alignItems:"center", gap:6, padding:"4px 10px", borderRadius:20, fontSize:11, fontWeight:600, letterSpacing:.5, textTransform:"uppercase",
              background:role==="admin"?"rgba(201,168,76,.15)":"rgba(96,165,250,.12)",
              color:role==="admin"?"var(--gold2)":"var(--blue)",
              border:`1px solid ${role==="admin"?"rgba(201,168,76,.3)":"rgba(96,165,250,.25)"}`
            }}>
              {role==="admin"?"⬡ Admin":"◯ Viewer"}
            </div>
          </div>
        </aside>

        {/* Main */}
        <div style={{ flex:1, overflow:"hidden", display:"flex", flexDirection:"column" }}>
          {/* Topbar */}
          <div style={{ background:"var(--surface)", borderBottom:"1px solid var(--border)", padding:"12px 24px", display:"flex", alignItems:"center", justifyContent:"space-between", flexShrink:0 }}>
            <div style={{ fontSize:15, fontWeight:600 }}>
              {NAVS.find(n=>n.id===tab)?.label}
            </div>
            <div style={{ display:"flex", alignItems:"center", gap:12 }}>
              <span style={{ fontSize:12, color:"var(--text3)" }}>{new Date().toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}</span>
              <div style={{ display:"flex", alignItems:"center", gap:8, fontSize:12 }}>
                <span style={{ color:"var(--text3)" }}>Role:</span>
                <select value={role} onChange={e=>setRole(e.target.value)}
                  style={{ background:"var(--surface2)", border:"1px solid var(--border2)", color:"var(--text)", padding:"5px 10px", borderRadius:6, fontSize:12, cursor:"pointer", outline:"none" }}>
                  <option value="admin">Admin</option>
                  <option value="viewer">Viewer</option>
                </select>
              </div>
            </div>
          </div>

          {/* Content */}
          <div style={{ flex:1, overflowY:"auto", padding:24 }}>
            {tab==="overview"     && <Overview transactions={dbState.transactions}/>}
            {tab==="transactions" && <Transactions transactions={dbState.transactions} role={role} dispatch={dispatch}/>}
            {tab==="insights"     && <Insights transactions={dbState.transactions}/>}
          </div>
        </div>
      </div>
    </>
  );
}
