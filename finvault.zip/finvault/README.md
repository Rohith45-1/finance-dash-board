# FinVault – Finance Dashboard

A clean, dark-themed personal finance dashboard built with **React + Recharts + Vite**.

## Features

### Dashboard Overview
- Summary cards: Total Balance, Income, Expenses, Transaction Count
- Line chart: Monthly cash flow (income vs expenses over time)
- Progress bars: Spending breakdown by category
- Recent transactions table

### Transactions Ledger
- Full sortable table (click any column header to sort asc/desc)
- Search by description or category
- Filter by type (income/expense) and category
- **Admin only**: Add, edit, delete transactions
- **Viewer**: read-only mode

### Insights & Reports
- Top spending category + share of total expenses
- Savings rate with qualitative assessment
- Monthly expense vs income bar chart (side-by-side)
- Donut chart: category distribution
- Month-over-month change indicators

### Role-Based UI
- Switch roles via the dropdown in the top bar
- **Admin**: full CRUD on transactions
- **Viewer**: read-only, no edit/delete/add buttons shown
- Role badge displayed in sidebar

### State Management
- `useReducer` for transaction data (ADD / EDIT / DELETE)
- `useState` for filters, sort, modal, role
- `useMemo` for derived data (totals, filtered lists, chart data)
- `localStorage` persistence — data survives page refresh

## Tech Stack

| Layer | Choice |
|-------|--------|
| Framework | React 18 |
| Build tool | Vite 5 |
| Charts | Recharts 2 |
| Styling | CSS-in-JS (style objects + global CSS string) |
| State | useReducer + useState |
| Persistence | localStorage |

## Design Decisions

- **Dark luxury aesthetic**: deep navy (`#0d1117`) background, gold (`#c9a84c`) accents — inspired by premium fintech apps
- **DM Serif Display** for headings (character + authority), **DM Sans** for data (clean readability)
- Category color system: each category has a consistent color used across badges, charts, and progress bars
- Responsive grid layout using CSS `auto-fit` / `minmax`

## Setup & Run

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Steps

```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev
# → Opens at http://localhost:5173

# 3. Build for production
npm run build

# 4. Preview production build
npm run preview
```

## Project Structure

```
finvault/
├── index.html          # HTML entry point
├── vite.config.js      # Vite configuration
├── package.json        # Dependencies
└── src/
    ├── main.jsx        # React root mount
    └── App.jsx         # Entire app (components + pages + state)
```

All code lives in `src/App.jsx` for simplicity. In a production project you would split into:
- `components/` (SummaryCard, CatBadge, Modal, etc.)
- `pages/` (Overview, Transactions, Insights)
- `hooks/` (useTransactions, useFilters)
- `store/` (reducer, initial state)
- `utils/` (formatters, data helpers)

## Assumptions

1. Currency is USD
2. Date format is YYYY-MM-DD (ISO 8601) for storage, displayed as-is
3. No authentication — role switching is simulated via dropdown
4. Data is mock/static on first load; persisted to localStorage thereafter
5. "Month-over-month" insight compares the two most recent months in the dataset
